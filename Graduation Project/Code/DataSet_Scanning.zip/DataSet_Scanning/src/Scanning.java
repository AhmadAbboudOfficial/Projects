
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class Scanning {

    public static void main(String[] args) {

        String Dir = "/home/fake/Desktop/Dataset/alt.atheism";
        ArrayList<String> files = Bulk.listFilesForFolder(new File(Dir));
        for (String file : files) {
            
            try {
                int count = 0;
                Scanner Reading = new Scanner(new File(Dir+"/"+file));
                while (Reading.hasNext()) {
                    String[] Line = Bulk.Splitter(Reading.nextLine());
                    for (String x : Line) {
                        if (x.length() != 0) {
                            //System.out.println(x);
                            count++;

                        }
                    }
                }
                System.out.println(file + " --> " + count );
            } catch (Exception e) {
            }
        }
    }

}
