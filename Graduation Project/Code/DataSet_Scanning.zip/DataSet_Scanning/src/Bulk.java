
import java.io.File;
import java.util.ArrayList;

public class Bulk {
    
    public static ArrayList<String> listFilesForFolder(final File folder) {
        ArrayList<String> All = new ArrayList<String>();
        for (final File fileEntry : folder.listFiles()) {
            if (fileEntry.isDirectory()) {
                continue;
            } else {
                All.add(fileEntry.getName());
            }
        }
        return (All);
    }
    
    public static String[] Splitter(String line) {
        String[] Newline = line.split(" ");
        return (Newline);
    }
}
