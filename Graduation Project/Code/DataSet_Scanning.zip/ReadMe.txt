this code is only used to
1) list all text files in a directory
2) count words in text file
