
import java.util.*;

public class Filtering {

    public static void main(String[] args) {
        FilterInput[] Filterslist = {new FilterInput(false, "/home/fake/Desktop/stopwords.txt"), new FilterInput(true, "/home/fake/Desktop/punctuation_list.txt"), new FilterInput(false, "/home/fake/Desktop/stopwords.txt"), new FilterInput(false, "/home/fake/Desktop/stopwords.txt")};
        String[] NewDirs = {"/home/fake/Desktop/bbc/After_StopwordsFilter/", "/home/fake/Desktop/bbc/After_PunctuationFilter/", "/home/fake/Desktop/bbc/final/", "/home/fake/Desktop/bbc/finals/"};

        Folder business = new Folder("business", "/home/fake/Desktop/bbc/raws/business/");
        business.setFiltersListsDirs(Filterslist);
        business.setNewDirs(NewDirs);
        business.Run();

        Folder entertainment = new Folder("entertainment", "/home/fake/Desktop/bbc/raws/entertainment/");
        entertainment.setFiltersListsDirs(Filterslist);
        entertainment.setNewDirs(NewDirs);
        entertainment.Run();

        Folder politics = new Folder("politics", "/home/fake/Desktop/bbc/raws/politics/");
        politics.setFiltersListsDirs(Filterslist);
        politics.setNewDirs(NewDirs);
        politics.Run();

        Folder sport = new Folder("sport", "/home/fake/Desktop/bbc/raws/sport/");
        sport.setFiltersListsDirs(Filterslist);
        sport.setNewDirs(NewDirs);
        sport.Run();

        Folder tech = new Folder("tech", "/home/fake/Desktop/bbc/raws/tech/");
        tech.setFiltersListsDirs(Filterslist);
        tech.setNewDirs(NewDirs);
        tech.Run();
    }

}
