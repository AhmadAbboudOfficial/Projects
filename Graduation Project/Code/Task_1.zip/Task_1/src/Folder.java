
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileWriter;

public class Folder {

    private String name;
    private String Dir;
    private Filter filter = null;
    private ArrayList<String> FilesList;
    private FilterInput[] filtersinput;
    private String[] NewDirs;

    public Folder(String name, String dir) {
        this.name = name;
        this.Dir = dir;
    }

    public void Run() {
        this.getFilesList();
        this.ExploreFiles();
    }

    public void setNewDirs(String[] NewDirs) {
        this.NewDirs = new String[NewDirs.length];

        for (int i = 0; i < this.NewDirs.length; i++) {
            this.NewDirs[i] = NewDirs[i] + "/" + name;
        }

    }

    public void setFiltersListsDirs(FilterInput[] filtersinput) {
        this.filtersinput = filtersinput;
    }

    public void getFilesList() {
        File folder = new File(Dir);
        ArrayList<String> All = new ArrayList<String>();
        for (final File fileEntry : folder.listFiles()) {
            if (fileEntry.isDirectory()) {
                continue;
            } else {
                All.add(fileEntry.getName());
            }
        }
        this.FilesList = All;
    }

    public void ExploreFiles() {
        ArrayList<String> F;
        ArrayList<String> F_words;
        for (String file : this.FilesList) {
            F_words = new ArrayList<String>();
            F = Folder.loadFile(Dir + "/" + file);
            for (String line : F) {
                String parts[] = line.split(" ");
                for (String p : parts) {
                    F_words.add(p);
                }
            }

            int count = 0;
            for (FilterInput f_input : this.filtersinput) {
                filter = new Filter(f_input);
                filter.getWordList();
                F_words = filter.Execute(F_words);
                this.saveFile(F_words, this.NewDirs[count] + "/" + file);
                count++;
            }
        }
    }

    public static ArrayList<String> loadFile(String Dir) {

        ArrayList<String> lines = new ArrayList<String>();
        try {
            Scanner Reading = new Scanner(new File(Dir));
            while (Reading.hasNext()) {
                lines.add(Reading.nextLine());
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error , Because of loadFile");
            System.exit(0);
        }
        return (lines);

    }

    private void saveFile(ArrayList<String> words, String dir) {
        try {
            FileWriter file = new FileWriter(new File(dir), true);
            for (String word : words) {
                file.write(word);
                file.write("\n");
            }
            file.flush();
            file.close();
        } catch (Exception e) {
            System.out.println("Error in saveFile" + e.getMessage());
        }
    }
}
