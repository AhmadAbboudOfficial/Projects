
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

final class FilterInput {

    private boolean Byletter;
    private String Dir;

    public FilterInput(boolean Byletter, String dir) {
        this.Byletter = Byletter;
        this.Dir = dir;
    }

    public boolean getByletter() {
        return (Byletter);
    }

    public String getDir() {
        return (Dir);
    }
}

public class Filter {

    private String WordListDir;
    private boolean Byletter;
    private ArrayList<String> WordsList;

    public Filter(FilterInput x) {
        this.Byletter = x.getByletter();
        this.WordListDir = x.getDir();
    }

    public void getWordList() {

        this.WordsList = Folder.loadFile(this.WordListDir);

    }

    public ArrayList<String> Execute(ArrayList<String> FileWordsList) {
        if (this.Byletter) {
            for (int Fileword = 0; Fileword < FileWordsList.size(); Fileword++) {
                for (String word : WordsList) {
                    if (FileWordsList.get(Fileword).contains(word)) {
                        String s = FileWordsList.get(Fileword).replace(word, "");
                        FileWordsList.set(Fileword, s);

                    }

                }

            }
            for (int i = 0; i < FileWordsList.size(); i++) {
                FileWordsList.remove("");
            }
        } else {
            for(int F_Word=0; F_Word<FileWordsList.size(); F_Word++){
                for(int Word=0; Word<this.WordsList.size(); Word++){
                    if(F_Word < FileWordsList.size()){
                    if(FileWordsList.get(F_Word).toLowerCase().equals(this.WordsList.get(Word).toLowerCase())){
                        FileWordsList.remove(F_Word);
                    }
                    }
                }
            }
       
        }

        return (FileWordsList);
    }

}
