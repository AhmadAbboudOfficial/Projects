package Classification;

import java.util.ArrayList;
import Mylib.*;
import java.util.HashMap;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author fake
 */
public class test {

    /*public static void main(String[] args) {
        CSVFile x = new CSVFile("/home/fake/Desktop/Mining/credit_card.csv");
        x.read();
        ArrayList<ArrayList<String>> dataset = x.getData();
        ArrayList<String> features_names = x.getColumnNames();
        features_names.remove(0);
        dataset.remove(0);
        DecisionTree Tree = new DecisionTree(dataset, features_names);
        Tree.BuildTree();
        HashMap<String, String> test = new HashMap<>();
        test.put("limit", "meduim");
        test.put("sex", "1");
        test.put("marriage", "1");
        test.put("age", "old");
        test.put("pay1", "paid");
        test.put("pay2", "paid");
        test.put("pay3", "paid");
        test.put("pay4", "paid");
        test.put("pay6", "paid");
        Tree.predict(test);

    }*/

}
